package entity;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity

public class Project {
    @Id
    @GeneratedValue
    private int id;
    private String name;
    private double budget;
    @ManyToMany
    @JoinTable(
            name = "employe_projet",
            joinColumns = @JoinColumn(name = "projet_id"),
            inverseJoinColumns = @JoinColumn(name = "employe_id")
    )
    private Set<Employer> employes = new HashSet<>();


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }
}
