package entity;

public enum Poste {
    MANAGER,
    DEV,
    TEST,
    DEVOPS,
    TECH_LEADER

}
