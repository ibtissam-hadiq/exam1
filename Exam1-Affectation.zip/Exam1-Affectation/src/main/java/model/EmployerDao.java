package model;

import entity.Employer;
import entity.Poste;
import entity.Project;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.List;

public class EmployerDao {
    private EntityManagerFactory entityManagerFactory;
    private EntityManager entityManager;

    public EmployerDao() {
        // Initialiser l'EntityManagerFactory
        entityManagerFactory = Persistence.createEntityManagerFactory("Eclipselink");
        // Créer une instance d'EntityManager
        entityManager = entityManagerFactory.createEntityManager();
    }

    public void insertEmp(Employer e) {
        entityManager.getTransaction().begin();
        entityManager.persist(e);
        entityManager.getTransaction().commit();
    }


    public Employer findEmp(int empid) {
        return entityManager.find(Employer.class, empid);
    }


    public void updateEmp(Employer data) {
        entityManager.getTransaction().begin();
        entityManager.merge(data);
        entityManager.getTransaction().commit();
    }


    public void deleteEmp(int empid) {
        Employer emp = findEmp(empid);
        if (emp != null) {
            entityManager.getTransaction().begin();
            entityManager.remove(emp);
            entityManager.getTransaction().commit();
        }
    }


    public List<Employer> readAllEmployees() {
        TypedQuery<Employer> query = entityManager.createQuery("select e from Employer e", Employer.class);
        return query.getResultList();
    }
    public List<Project> getProjetsParEmploye(Long employeId) {
        Employer employe = entityManager.find(Employer.class, employeId);
        if (employe != null) {
            return employe.getProjets();
        }
        return new ArrayList<>();
    }


    public void close() {
        if (entityManager != null) {
            entityManager.close();
        }
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }
    public Poste getPosteEmploye(Long employeId) {
        Employer employe = entityManager.find(Employer.class, employeId);
        if (employe != null) {
            return employe.getPoste();
        }
        return null;
    }

}
