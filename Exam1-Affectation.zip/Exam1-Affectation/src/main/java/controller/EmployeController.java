package controller;

import entity.Employer;
import entity.Poste;
import entity.Project;
import model.EmployerDao;

import java.util.List;

public class EmployeController {
    private Employer employer;
    private List<Employer> employers;
    private List<Project> projets;
    private Poste poste;
    private EmployerDao employerDao;
    public EmployeController(){
        employerDao = new EmployerDao();
        employers = employerDao.readAllEmployees();
    }
    public void insertEmp() {
        employerDao.insertEmp(employer);
        employers = employerDao.readAllEmployees(); // Mettre à jour la liste des employés
    }

    public Employer findEmp(int empid) {
        return employerDao.findEmp(empid);
    }

    public void updateEmp() {
        employerDao.updateEmp(employer);
        employers = employerDao.readAllEmployees(); // Mettre à jour la liste des employés
    }

    public void deleteEmp(int empid) {
        employerDao.deleteEmp(empid);
        employers = employerDao.readAllEmployees(); // Mettre à jour la liste des employés
    }

    public List<Project> getProjetsParEmploye(Long employeId) {
        return employerDao.getProjetsParEmploye(employeId);
    }

    public Poste getPosteEmploye(Long employeId) {
        return employerDao.getPosteEmploye(employeId);
    }

    public void close() {
        employerDao.close();
    }
}
